# Copyright (c) 2010-2023 openpyxl

from .external import ExternalLink
